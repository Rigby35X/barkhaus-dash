import { useLiveSite } from '../../../../contexts/LiveSiteContext';

const Header = () => {
  const config = useLiveSite();
  if (!config) return null;

  return (
    <header className="bg-white shadow">
      <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
        <div className="text-xl font-bold text-primary-600">{config.site_name}</div>
        <nav className="space-x-6">
          <a href="#about" className="text-gray-600 hover:text-primary-600">About</a>
          <a href="#mission" className="text-gray-600 hover:text-primary-600">Mission</a>
          <a href="#available-pets" className="text-gray-600 hover:text-primary-600">Available Dogs</a>
          <a href="#contact" className="text-gray-600 hover:text-primary-600">Contact</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;