import { useLiveSite } from '../../../../contexts/LiveSiteContext';


const Hero = () => {
  const config = useLiveSite();

  if (!config) return null;

  return (
    <section className="py-16" style={{ backgroundColor: config.primary_color, color: config.background_color }}>
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">{config.site_name}</h1>
        <p className="text-lg md:text-xl mb-6">{config.tagline}</p>
        <a
          href="#available-pets"
          className="inline-block bg-white text-primary-600 font-semibold px-6 py-3 rounded hover:bg-gray-100"
        >
          Meet Our Dogs
        </a>
      </div>
    </section>
  );
};

export default Hero;
