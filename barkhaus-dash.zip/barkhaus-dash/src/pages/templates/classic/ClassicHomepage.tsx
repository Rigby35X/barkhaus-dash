import Header from './sections/Header';
import Hero from './sections/Hero';
import About from './sections/About';
import Mission from './sections/Mission';
import AvailablePets from './sections/AvailablePets';
import Footer from './sections/Footer';

const ClassicHomepage = () => {
  return (
    <>
      <Header />
      <Hero />
      <About />
      <Mission />
      <AvailablePets />
      <Footer />
    </>
  );
};

export default ClassicHomepage;
import { useLiveSite } from '../../../contexts/LiveSiteContext';