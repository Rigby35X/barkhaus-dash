import React from "react";

const TemplatesPage = () => {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-4">Templates</h1>
      <p className="text-gray-600">This is the templates page. 🎉</p>
    </div>
  );
};

export default TemplatesPage;
