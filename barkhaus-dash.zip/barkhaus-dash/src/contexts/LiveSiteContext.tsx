import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';

type LiveSiteData = {
  site_name: string;
  tagline: string;
  mission: string;
  logo_url: string;
  primary_color: string;
  secondary_color: string;
  background_color: string;
  heading_font_family: string;
  body_font_family: string;
  google_heading_font_link: string;
  google_body_font_link: string;
};

const LiveSiteContext = createContext<LiveSiteData | null>(null);

export const useLiveSite = () => {
  return useContext(LiveSiteContext);
};

export const LiveSiteProvider = ({ children }: { children: React.ReactNode }) => {
  const [config, setConfig] = useState<LiveSiteData | null>(null);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await axios.get('https://x8ki-letl-twmt.n7.xano.io/api:nS8IsiFR/get-live-site-config');
        setConfig(res.data);
      } catch (error) {
        console.error('Failed to fetch LiveSite config:', error);
      }
    };

    fetchConfig();
  }, []);

  return <LiveSiteContext.Provider value={config}>{children}</LiveSiteContext.Provider>;
};
